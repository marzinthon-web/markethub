# MarketHub — Pi Login
This build adds the official Pi JavaScript SDK and Pi authentication. Production uses `Pi.init({ version: "2.0", sandbox: false })`.

## Required Vercel secret
Add an Environment Variable named `PI_API_KEY` containing your Pi Server API Key. Keep it server-side; never put it in frontend files or share it in chat.

The `/api/auth` endpoint verifies the Pi access token against the Pi Platform API. Real Pi payments are not included yet.
