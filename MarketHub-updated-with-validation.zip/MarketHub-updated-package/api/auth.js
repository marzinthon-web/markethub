export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
  const apiKey=process.env.PI_API_KEY;
  if(!apiKey) return res.status(500).json({error:'PI_API_KEY is not configured'});
  try{
    const {accessToken}=req.body||{};
    if(!accessToken) return res.status(400).json({error:'Missing access token'});
    const r=await fetch('https://api.minepi.com/v2/me',{headers:{Authorization:`Bearer ${accessToken}`,'X-API-Key':apiKey}});
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error||'Pi token verification failed'});
    return res.status(200).json({verified:true,user:data});
  }catch(e){return res.status(500).json({error:'Server error'});}
}
